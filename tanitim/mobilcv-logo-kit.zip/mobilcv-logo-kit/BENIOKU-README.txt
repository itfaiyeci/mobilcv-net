MobilCV logo paketi / logo kit

TR
- mobilcv-logo.svg / .png: açık zemin için (Mobil = #0f172a, CV = #2563eb)
- mobilcv-logo-white.svg / .png: koyu veya renkli zemin için
- mobilcv-icon-512.png: kare simge
Logoyu MobilCV'ye bağlantı vermek, afiş ya da duyurularınızda aracı tanıtmak için kullanabilirsiniz.
Lütfen logoyu yeniden renklendirmeyin, oranlarını bozmayın ve MobilCV'nin kurumunuzla resmi bir ortaklığı
varmış izlenimi verecek şekilde kullanmayın (böyle bir ortaklık için bize yazın).
İletişim: info@mobilcv.com

EN
- mobilcv-logo.svg / .png: for light backgrounds (Mobil = #0f172a, CV = #2563eb)
- mobilcv-logo-white.svg / .png: for dark or coloured backgrounds
- mobilcv-icon-512.png: square icon
You may use the logo to link to MobilCV or to introduce the tool on posters and announcements.
Please do not recolour or distort it, or use it in a way that suggests an official partnership with your
organisation (write to us if you would like one).
Contact: info@mobilcv.com
